function[mapping]=map_expression_2_data(model, data,dico,  probeID)
%% Maria Pires Pacheco & Thomas Sauter 25.03.2014 - System biology group % University of Luxembourg
%% search the dataIds in the dictionnary
% [~,IA,loc]=intersect(dico(:,1),probeID);

col=find(sum(ismember(dico,probeID)));

[~,IA,loc]=intersect(dico(:,col),probeID);

if isempty(loc)
    'the dico does match the dataIds';
    return
end
mapped2(:,1)=probeID(loc,1);
mapped2(:,2)=dico(IA,1);
mapped2(:,3)=dico(IA,2);
mapped=data(loc,:);
mapped_to_genes=zeros(numel(model.genes), size(mapped,2));
% maps the expression data to the genes
for i=1:numel(model.genes)
    match=find(strcmp(mapped2(:,3),model.genes(i)));
    if numel(match)==1
        mapped_to_genes(i,:)=mapped(match,:);
    elseif isempty(match)
        'gene is not in the data'
        
    else
        mapped_to_genes(i,:)=max(mapped(match,:),[],1); % take the highest value if
        %more probeIDs correspond to one modelID
    end
end
mapping=zeros(numel(model.rxns), size(mapped,2));
% maps the expression data ti the reactions
for j= 1:size(mapped_to_genes,2)
    x=mapped_to_genes(:,j);
    for k=1:numel(model.rxns)
        mapping(k,j)= GPRrulesMapper(cell2mat(model.rules(k)),x);
    end
end
end


